package com.example.flutter_uts_2301081003_a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
