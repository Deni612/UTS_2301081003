import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warnet App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
      routes: {
        '/transaksi': (context) => TransaksiScreen(),
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              child: Text('Menu'),
              decoration: BoxDecoration(color: Colors.blue),
            ),
            ListTile(
              title: Text('Transaksi'),
              onTap: () {
                Navigator.pushNamed(context, '/transaksi');
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Text('Selamat datang di Warnet!'),
      ),
    );
  }
}

class Pelanggan {
  final String kode;
  final String nama;

  Pelanggan(this.kode, this.nama);
}

class Warnet {
  final String kodeTransaksi;
  final Pelanggan namaPelanggan;
  final String jenisPelanggan;
  final DateTime tglMasuk;
  final DateTime jamMasuk;
  final DateTime jamKeluar;
  final double tarif;

  Warnet({
    required this.kodeTransaksi,
    required this.namaPelanggan,
    required this.jenisPelanggan,
    required this.tglMasuk,
    required this.jamMasuk,
    required this.jamKeluar,
    required this.tarif,
  });

  double hitungTotalBayar() {
    final lama = jamKeluar.difference(jamMasuk).inHours.toDouble();
    double diskon = 0;

    if (jenisPelanggan == "VIP" && lama > 2) {
      diskon = 0.02 * (lama * tarif);
    } else if (jenisPelanggan == "GOLD" && lama > 2) {
      diskon = 0.05 * (lama * tarif);
    }

    return (lama * tarif) - diskon;
  }

  double getLamaPenggunaan() {
    return jamKeluar.difference(jamMasuk).inHours.toDouble();
  }
}

class TransaksiScreen extends StatefulWidget {
  @override
  _TransaksiScreenState createState() => _TransaksiScreenState();
}

class _TransaksiScreenState extends State<TransaksiScreen> {
  final TextEditingController kodeTransaksiController = TextEditingController();
  final TextEditingController namaPelangganController = TextEditingController();
  final TextEditingController jenisPelangganController = TextEditingController();
  final TextEditingController tarifController = TextEditingController();

  DateTime jamMasuk = DateTime.now();
  DateTime jamKeluar = DateTime.now().add(Duration(hours: 3)); // Default 3 jam

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Transaksi')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: kodeTransaksiController,
              decoration: InputDecoration(labelText: 'Kode Transaksi'),
            ),
            TextField(
              controller: namaPelangganController,
              decoration: InputDecoration(labelText: 'Nama Pelanggan'),
            ),
            TextField(
              controller: jenisPelangganController,
              decoration: InputDecoration(labelText: 'Jenis Pelanggan (VIP/GOLD)'),
            ),
            TextField(
              controller: tarifController,
              decoration: InputDecoration(labelText: 'Tarif per Jam'),
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              onPressed: () {
                final pelanggan = Pelanggan(
                  kodeTransaksiController.text,
                  namaPelangganController.text,
                );

                final warnet = Warnet(
                  kodeTransaksi: kodeTransaksiController.text,
                  namaPelanggan: pelanggan,
                  jenisPelanggan: jenisPelangganController.text,
                  tglMasuk: DateTime.now(),
                  jamMasuk: jamMasuk,
                  jamKeluar: jamKeluar,
                  tarif: double.tryParse(tarifController.text) ?? 0,
                );

                final totalBayar = warnet.hitungTotalBayar();
                final lamaPenggunaan = warnet.getLamaPenggunaan();
                final formatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ');

                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Total Bayar'),
                    content: Text('Lama Penggunaan: ${lamaPenggunaan.toStringAsFixed(0)} jam\n'
                                  'Total yang harus dibayar: ${formatter.format(totalBayar)}'),
                    actions: [
                      TextButton(
                        child: Text('OK'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  ),
                );
              },
              child: Text('Hitung Total Bayar'),
            ),
          ],
        ),
      ),
    );
  }
}
